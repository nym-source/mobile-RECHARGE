﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;

namespace WebApplication7
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        OleDbCommand cmd;
        OleDbConnection con;
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\carry\Desktop\WebApplication7\WebApplication7\database\Database31.accdb");
           cmd = new OleDbCommand("insert into signup ( name1,IDName,em,mobileno,pass ) values('"+TextBox1.Text+"','"+TextBox2.Text+"','"+TextBox3.Text+"',"+TextBox4.Text+",'" + TextBox5.Text + "')");
            //cmd = new OleDbCommand("insert into signup (name,IDName,Email,mobileno,password) values(" + TextBox1.text + "," + TextBox2.text + "," + TextBox3.text + "," + TextBox4.text + ")");
           Response.Redirect("WebForm6.aspx");
            con.Open();
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
             Session["a1"]=Convert.ToString(TextBox1.Text);             
            TextBox1.Text="";     
            TextBox2.Text="";
            TextBox3.Text="";
            TextBox4.Text="";
            con.Close();
        }
 }
}