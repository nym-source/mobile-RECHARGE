﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;

namespace WebApplication7
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        OleDbCommand cmd;
        OleDbConnection con;
        OleDbDataReader r;
        public void Page_Load(object sender, EventArgs e)
        {
                       
                    }

        public void Button1_Click(object sender, EventArgs e)
        {
            con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\carry\Desktop\WebApplication7\WebApplication7\database\Database31.accdb");
            cmd = new OleDbCommand("select * from signup where mobileno=" + TextBox1.Text + " and pass='" + TextBox2.Text + "'");
            con.Open();
            cmd.Connection = con;
            r = cmd.ExecuteReader();
            if (r.Read())
            {
                Session["ab"] = Convert.ToString(TextBox1.Text);
                Response.Redirect("WebForm4.aspx");
            }
            con.Close();
            
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            Response.Redirect("WebForm7.aspx");
        }

            }
}