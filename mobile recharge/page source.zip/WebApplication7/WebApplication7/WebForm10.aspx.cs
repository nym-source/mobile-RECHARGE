﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication7
{
    public partial class WebForm10 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        

       

        protected void Button1_Click(object sender, EventArgs e)
        {
            Session["ab"] = Convert.ToString(Button1.Text);
            Response.Redirect("WebForm4.aspx");
        }

      protected void Button4_Click(object sender, EventArgs e)
        {
            Session["bc"] = Convert.ToString(Button4.Text);
            Response.Redirect("WebForm4.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Session["cd"] = Convert.ToString(Button2.Text);
            Response.Redirect("WebForm4.aspx");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Session["de"] = Convert.ToString(Button3.Text);
            Response.Redirect("WebForm4.aspx");
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            Session["ef"] = Convert.ToString(Button5.Text);
            Response.Redirect("WebForm4.aspx");
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            Session["fg"] = Convert.ToString(Button6.Text);
            Response.Redirect("WebForm4.aspx");
        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            Session["gh"] = Convert.ToString(Button7.Text);
            Response.Redirect("WebForm4.aspx");
        }

        protected void Button8_Click(object sender, EventArgs e)
        {
            Session["hi"] = Convert.ToString(Button8.Text);
            Response.Redirect("WebForm4.aspx");
        }
    }
}