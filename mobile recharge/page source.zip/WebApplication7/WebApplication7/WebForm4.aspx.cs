﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;

namespace WebApplication7
{
    public partial class WebForm4 : System.Web.UI.Page
    {
       OleDbCommand cmd;
       OleDbConnection con;
        protected void Page_Load(object sender, EventArgs e)
        {
     //     TextBox2.Text = Convert.ToString(Session["a1"]);
       /*   TextBox1.Text = Convert.ToString(Session["ab"]);
          TextBox1.Text = Convert.ToString(Session["bc"]);
          TextBox1.Text = Convert.ToString(Session["cd"]);
          TextBox1.Text = Convert.ToString(Session["de"]);
          TextBox1.Text = Convert.ToString(Session["ef"]);
          TextBox1.Text = Convert.ToString(Session["fg"]);
          TextBox1.Text = Convert.ToString(Session["gh"]);
          TextBox1.Text = Convert.ToString(Session["hi"]);*/
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\carry\Desktop\WebApplication7\WebApplication7\database\Database31.accdb");
            cmd = new OleDbCommand("insert into pay(nu,op,st,am) values(" + TextBox2.Text + ",'" + DropDownList1.SelectedItem.Value.ToString() + "','" + DropDownList2.SelectedItem.Value.ToString() + "'," + TextBox1.Text + ")");
           
            con.Open();
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            TextBox1.Text = "";
            TextBox2.Text = "";
            con.Close();
                 }
                  
    }
}