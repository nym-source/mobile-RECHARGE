﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;

namespace WebApplication7
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        OleDbCommand cmd;
        OleDbConnection con;
        OleDbDataReader r;
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\carry\Desktop\WebApplication7\WebApplication7\database\Database31.accdb");
            cmd = new OleDbCommand("select * from signup where IDName='" + TextBox1.Text + "' and mobileno=" + TextBox2.Text +"and em= '"+TextBox3.Text+"'");
            con.Open();
            cmd.Connection = con;
            r = cmd.ExecuteReader();
            if (r.Read())
            {
                Session["a2"] = Convert.ToString(TextBox1.Text);
                Response.Redirect("WebForm3.aspx");
            }
            else 
            {
                Response.Redirect("webform7.aspx");
            }
            con.Close();        
            
                   }
    }
}